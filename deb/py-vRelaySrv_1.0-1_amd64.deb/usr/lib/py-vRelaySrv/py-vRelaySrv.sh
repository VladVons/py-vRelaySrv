#!/bin/bash
#--- VladVons@gmail.com

#/usr/bin/env python3 py-vRelaySrv.py
/usr/bin/env python3 -B py-vRelaySrv.py
